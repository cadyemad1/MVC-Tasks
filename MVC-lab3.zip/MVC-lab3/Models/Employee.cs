﻿using MVC_lab3.Models.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MVC_lab3.Models
{
    public class Employee
    {
        public int Id { get; set;}
        [Required]
        public String Name { get; set; }
        [Required]
        [EmailAddress]
        public String Email { get; set; }

        [Range(1000,5000)]
        [DataType(DataType.Currency)]
        public int Salary { get; set; }
        public Gender Gender { get; set; }
    }
}