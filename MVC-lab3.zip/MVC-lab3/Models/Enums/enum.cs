﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVC_lab3.Models.Enums
{

    public enum Gender
{
    Female=0,
    male=1
}
}