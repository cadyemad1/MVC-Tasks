﻿using MVC_lab3.DAL;
using MVC_lab3.Models;
using MVC_lab3.ViewModels;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVC_lab3.Controllers
{
    public class EmployeesController : Controller
    {
        applicationDbContext ctx = new applicationDbContext();
        public ActionResult Index()
        {
            EmployeeViewModel evm = new EmployeeViewModel
            {
                Employees = ctx.Employees.ToList()
            };
            return View(evm);
        }

        public ViewResult Add()
        {
            ViewBag.Action = "Add";
            return View("EmployeeForm");
        }

        [HttpPost]
        public ActionResult Add(Employee employee)
        {
            if (ModelState.IsValid)
            {
                ctx.Employees.Add(employee);
                ctx.SaveChanges();
                TempData["msg"] = "Employee Added!";
                return RedirectToAction("Index"); 
            }
            return View("EmployeeForm");
        }

        [HttpPost]
        public ActionResult AddAjax(Employee employee)
        {
            if (ModelState.IsValid)
            {
                ctx.Employees.Add(employee);
                ctx.SaveChanges();
                TempData["msg"] = "Employee Added!";
                //return Json(employee);
                return PartialView("_EmployeePartial", employee);
            }
            return Json(ModelState);
        }


        public ActionResult EmployeeDetails(int id)
        {
            Employee emp = ctx.Employees.FirstOrDefault(e => e.Id == id);
            if(emp != null)
            {
                //ViewBag.Employee = emp;
                return View(emp);
            }
            else
            {
                return RedirectToAction("Index");
            }
        }


         [HttpPost]
        public ActionResult Delete(int id)
        {
            Employee emp = ctx.Employees.FirstOrDefault(e => e.Id == id);
            if (emp != null)
            {
                ctx.Employees.Remove(emp);
                ctx.SaveChanges();
                return Json(true);
            }
            return HttpNotFound("No emp found");
        }

         [HttpGet]
        public ActionResult Edit(int id)
        {
            Employee emp = ctx.Employees.FirstOrDefault(e => e.Id == id);
            if (emp != null)
            {
                ViewBag.Action = "Edit";
                TempData["msg"] = "Employee Edited!";
                return View("EmployeeForm",emp);
            }
            return HttpNotFound("No emp found");
        }

        [HttpPost]
        public ActionResult Edit(Employee emp)
        {
            if (ModelState.IsValid)
            {
                ctx.Employees.Attach(emp);
                ctx.Entry(emp).State = EntityState.Modified;
                ctx.SaveChanges();
                return RedirectToAction(nameof(Index));
             }
            return View("EmployeeForm",emp);
        }

    }
}