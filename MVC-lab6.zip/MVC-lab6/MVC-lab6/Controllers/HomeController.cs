﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using MVC_lab6.Models;

namespace MVC_lab6.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
        [AllowAnonymous]
        public ActionResult Index()
        {
            ApplicationUserManager userManager = new ApplicationUserManager(new UserStore<ApplicationUser>(new ApplicationDbContext()));
            ApplicationUser admin = userManager.FindByEmail("admin@gmail.com");
            ApplicationUser manager = userManager.FindByEmail("manager@gmail.com");
            ApplicationUser client = userManager.FindByEmail("client@gmail.com");
            userManager.AddToRole(admin.Id, "Admin");
            userManager.AddToRole(manager.Id, "Manager");
            userManager.AddToRole(client.Id, "Client");

            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
        public ActionResult Admin()
        {
            

            return View();
        }

        [Authorize(Roles = "Admin")]
        public ActionResult ForAdmin()
        {
           

            return View();
        }
        [Authorize(Roles = "Admin,Manager")]
        public ActionResult ForManager()
        {
        

            return View();
        }
        [Authorize(Roles = "Admin,Client")]
        public ActionResult ForClient()
        {


            return View();
        }
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult AddRolet(IdentityRole role)
        {
            if (ModelState.IsValid)
            {
                RoleManager<IdentityRole> roleManager = new RoleManager<IdentityRole>(new RoleStore<IdentityRole>(new ApplicationDbContext()));
                roleManager.Create(role);
                 return RedirectToAction("Index");
            }


            return View();
        }
    }
}